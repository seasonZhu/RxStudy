//
//  AppState.swift
//  RxStudy
//
//  Created by dy on 2022/10/9.
//  Copyright © 2022 season. All rights reserved.
//

import Combine

public class AppState: ObservableObject {
    @Published public var isBack: Bool = false
    
    public init(isBack: Bool = false) {
        self.isBack = isBack
    }
}
