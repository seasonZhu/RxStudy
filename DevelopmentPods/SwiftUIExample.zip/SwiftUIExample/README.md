# SwiftUIExample

[![CI Status](https://img.shields.io/travis/zhujilong1987@163.com/SwiftUIExample.svg?style=flat)](https://travis-ci.org/zhujilong1987@163.com/SwiftUIExample)
[![Version](https://img.shields.io/cocoapods/v/SwiftUIExample.svg?style=flat)](https://cocoapods.org/pods/SwiftUIExample)
[![License](https://img.shields.io/cocoapods/l/SwiftUIExample.svg?style=flat)](https://cocoapods.org/pods/SwiftUIExample)
[![Platform](https://img.shields.io/cocoapods/p/SwiftUIExample.svg?style=flat)](https://cocoapods.org/pods/SwiftUIExample)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

SwiftUIExample is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'SwiftUIExample'
```

## Author

zhujilong1987@163.com, zhujilong1987@163.com

## License

SwiftUIExample is available under the MIT license. See the LICENSE file for more info.
