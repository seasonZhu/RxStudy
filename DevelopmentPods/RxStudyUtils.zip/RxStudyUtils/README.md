# RxStudyUtils

[![CI Status](https://img.shields.io/travis/zhujilong1987@163.com/RxStudyUtils.svg?style=flat)](https://travis-ci.org/zhujilong1987@163.com/RxStudyUtils)
[![Version](https://img.shields.io/cocoapods/v/RxStudyUtils.svg?style=flat)](https://cocoapods.org/pods/RxStudyUtils)
[![License](https://img.shields.io/cocoapods/l/RxStudyUtils.svg?style=flat)](https://cocoapods.org/pods/RxStudyUtils)
[![Platform](https://img.shields.io/cocoapods/p/RxStudyUtils.svg?style=flat)](https://cocoapods.org/pods/RxStudyUtils)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

RxStudyUtils is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'RxStudyUtils'
```

## Author

zhujilong1987@163.com, zhujilong1987@163.com

## License

RxStudyUtils is available under the MIT license. See the LICENSE file for more info.
