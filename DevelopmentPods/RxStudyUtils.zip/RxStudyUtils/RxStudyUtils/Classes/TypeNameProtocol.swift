//
//  TypeNameProtocol.swift
//  RxStudy
//
//  Created by dy on 2022/7/1.
//  Copyright © 2022 season. All rights reserved.
//

import Foundation


public protocol TypeNameProtocol {
    
    var className: String { get }
    
    static var className: String { get }
    
}

extension TypeNameProtocol {
    
    public var className: String { String(describing: self) }
    
    public static var className: String { String(describing: self) }
    
    /// 用于非继承NSObject的class\enum\struct去掉命名空间的名称打印
    public var classNameWithoutNamespace: String {
        
        if self is NSObject {
            return className
        } else {
            return String(className.split(separator: ".").last!)
        }
    }
    
    public static var classNameWithoutNamespace: String {
        if self is NSObject.Type {
            return className
        } else {
            return String(className.split(separator: ".").last!)
        }
    }
    
}

extension TypeNameProtocol where Self: AnyObject {
    /// 获取对象的内存地址(class类才有)
    public var memoryAddress: String {
        return "<\(classNameWithoutNamespace): \(Unmanaged.passUnretained(self).toOpaque())>"
    }
}

class Student {}

class Teacher: NSObject {}

extension Student: TypeNameProtocol {}

extension NSObject: TypeNameProtocol {}
