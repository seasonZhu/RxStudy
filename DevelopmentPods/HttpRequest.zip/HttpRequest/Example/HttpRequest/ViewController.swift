//
//  ViewController.swift
//  HttpRequest
//
//  Created by zhujilong1987@163.com on 11/24/2022.
//  Copyright (c) 2022 zhujilong1987@163.com. All rights reserved.
//

import UIKit
import HttpRequest

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        myProvider.rx.request(MyService.userCoinInfo).subscribe { event in
            switch event {
                
            case .success(let json):
                print(json)
            case .failure(let error):
                print(error)
            }
        }.disposed(by: rx.disposeBag)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

}

