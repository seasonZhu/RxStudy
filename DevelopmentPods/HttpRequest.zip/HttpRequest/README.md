# HttpRequest

[![CI Status](https://img.shields.io/travis/zhujilong1987@163.com/HttpRequest.svg?style=flat)](https://travis-ci.org/zhujilong1987@163.com/HttpRequest)
[![Version](https://img.shields.io/cocoapods/v/HttpRequest.svg?style=flat)](https://cocoapods.org/pods/HttpRequest)
[![License](https://img.shields.io/cocoapods/l/HttpRequest.svg?style=flat)](https://cocoapods.org/pods/HttpRequest)
[![Platform](https://img.shields.io/cocoapods/p/HttpRequest.svg?style=flat)](https://cocoapods.org/pods/HttpRequest)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

HttpRequest is available through [CocoaPods](https://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod 'HttpRequest'
```

## Author

zhujilong1987@163.com, zhujilong1987@163.com

## License

HttpRequest is available under the MIT license. See the LICENSE file for more info.
