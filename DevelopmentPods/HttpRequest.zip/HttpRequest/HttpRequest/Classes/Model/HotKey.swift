//
//  HotKey.swift
//  RxStudy
//
//  Created by season on 2021/5/28.
//  Copyright © 2021 season. All rights reserved.
//

import Foundation

public struct HotKey : Codable {

    public let id : Int?
    public let link : String?
    public let name : String?
    public let order : Int?
    public let visible : Int?

}
