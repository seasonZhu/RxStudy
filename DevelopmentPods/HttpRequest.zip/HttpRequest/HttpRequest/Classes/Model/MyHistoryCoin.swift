//
//  MyHistoryCoin.swift
//  RxStudy
//
//  Created by season on 2021/6/15.
//  Copyright © 2021 season. All rights reserved.
//

import Foundation

public struct MyHistoryCoin: Codable {
    public let coinCount : Int?
    public let date : Int?
    public let desc : String?
    public let id : Int?
    public let reason : String?
    public let type : Int?
    public let userId : Int?
    public let userName : String?
}
