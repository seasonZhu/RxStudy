//
//  Friend.swift
//  RxStudy
//
//  Created by dy on 2022/6/28.
//  Copyright © 2022 season. All rights reserved.
//

import Foundation

public struct Friend : Codable {

    public let category : String?
    public let icon : String?
    public let id : Int?
    public let link : String?
    public let name : String?
    public let order : Int?
    public let visible : Int?
}
