//
//  Dictionary+Extension.swift
//  RxStudy
//
//  Created by season on 2021/5/20.
//  Copyright © 2021 season. All rights reserved.
//

import Foundation

extension Dictionary {
    /// 空字典
    public static var empty: Dictionary { [:] }
}
