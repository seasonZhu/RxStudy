//
//  Int+Extension.swift
//  RxStudy
//
//  Created by season on 2021/5/20.
//  Copyright © 2021 season. All rights reserved.
//

import Foundation

extension Int {
    public var toString: String { "\(self)" }
    
    public var greaterThanZero: Bool { self > 0 }
}
