//
//  Collection+Extension.swift
//  RxStudy
//
//  Created by dy on 2022/6/6.
//  Copyright © 2022 season. All rights reserved.
//

import Foundation

extension Collection {
    public var isNotEmpty: Bool { !isEmpty }
}
